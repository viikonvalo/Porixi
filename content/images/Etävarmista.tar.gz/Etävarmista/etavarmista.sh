#! /bin/bash
# Bash script to copy a set of remote directories to local dir
# using rsync. 
# Copyright Tapio Lehtonen 2010
# 
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 3
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
#
# Tapio Lehtonen <tale@iki.fi> http://taleman.fi/

# $Id: etavarmista.sh 25 2010-09-08 08:54:00Z taleman $
# Backup first day of month to directory YYYY-MM-DD, ie date +%F
# Backup on days 9, 17, 25 of month to directory date +"%d", ie day of month
# Backup other days directory date +"%A", ie weekday name
# This way disk space is reused after one month except the directory
# made on first day of month, which is not overwritten.
#
# usage: etavarmista.sh -f FROMHOST -r RSYNCTODIR -t TDIR FROMDIR [FROMDIR]*

###set -x
set -e

TEMP=`getopt -o f:r:t:vh --long fromhost:,rsynctodir:,tdir:verbose,help \
    -n 'etavarmista.sh' -- "$@"`

if [ $? != 0 ] ; then echo "Terminating..." >&2 ; exit 1 ; fi

eval set -- "$TEMP"
VERBOSE="False"
RSYNCTODIR="EMPTY"
GIVEHELP="False"

while true ; do
    case "$1" in
	-f|--fromhost) FROMHOST=$2 ; shift 2 ;;
	-r|--rsynctodir) RSYNCTODIR=$2 ; shift 2 ;;
	-t|--tdir) TDIR=$2 ; shift 2 ;;
	-v|--verbose) VERBOSE="True" ; shift ;;
	-h|--help) GIVEHELP="True"; shift ;;
	--) shift ; break ;;
	*) echo "Internal error!" ; exit 1;;
    esac
done

if [ $GIVEHELP == "True" ] ; then
    echo "Make backup of possibly remote directories with rsync --link-dest."
    echo "usage: $0 -f FROMHOST [-r RSYNCTODIR] -t TDIR [-v] DIRNAMES+ "
    echo "       $0 (-h|--help)"
    echo ""
    echo "Tapio Lehtonen 2010"
    exit 0
fi

MDAY=`date +%-d`
WEEKDAY=`date +%A`
MODULUS=$((MDAY%8))
if [ $VERBOSE != "False" ]; then
    echo "Modulus is $MODULUS"
fi

if [ $MDAY -eq 1 ] ; then
    # First day of month, make a copy that is not overwritten 
    # within a month.
    CDATE=`date +%F`
#Is day of month mod 8 == 1?
elif [ $MODULUS -eq 1 ] ; then
    # Yes it is, thus it is 09, 17, 25 (since 1st in previous if)
    # Backup to directory named after day of month 
    CDATE=$MDAY
else
    # Some other day of month
    # Full backup to dir named day of week
    CDATE=$WEEKDAY
fi
if [ $VERBOSE != "False" ] ; then
    echo "Copy going to directory $CDATE"
fi

if [ $RSYNCTODIR == "EMPTY" ] ; then
    RSYNCTODIR=$TDIR/LATEST
fi
if [ $VERBOSE != "False" ] ; then
    echo "Doing rsync with link-dest as "  $RSYNCTODIR
fi

TARGETDIR=$TDIR/$CDATE
if [ -d $TARGETDIR ] ; then
    if [ $VERBOSE != "False" ]; then
	echo "Removing old backup $TARGETDIR"
    fi
    mv $TARGETDIR $TDIR/FOOBAR.$$
fi

for arg do 
   if [ $VERBOSE != "False" ] ; then
       echo "<-- " "$arg"
   fi
   COMMAND="rsync -az --delete --link-dest=$RSYNCTODIR $FROMHOST$arg $TARGETDIR"
   $COMMAND
   if [ $? != 0 ] ; then
       echo "Error, backup not done or not complete."
       echo $COMMAND
       exit 1
   fi
done

cd $TDIR
if [ -L LATEST ] ; then
    rm LATEST
fi
ln -s $CDATE LATEST
if [ -d $TDIR/FOOBAR.$$ ] ; then
    rm -rf $TDIR/FOOBAR.$$
fi
