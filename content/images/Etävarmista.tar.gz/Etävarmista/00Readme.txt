Kuvaus
======

Bash-komentotiedosto etavarmista.sh tekee varmuuskopion halutuista
hakemistopuista rsync-komennolla. Ensimmäisen varmuuskopion ottaminen
kestää kauan, mutta sen jälkeen kopio tulee hyvin nopeasti.

Komentotiedosto on tarkoitettu suoritettavaksi kerran päivässä. Päivän
varmuuskopio menee omaan alihakemistoonsa, näin voi palauttaa
tiedostoja sellaisina kuin ne olivat tiettynä
päivänä. Varmuuskopiohakemistot uusiokäytetään kuukauden kuluttua,
näin levy ei täyty alihakemistoista. Kuukauden ensimmäisen päivän
varmuuskopio säilytetään, niitä komentotiedosto ei poista, mutta ne
voi poistaa itse jos haluaa. 

Hyödynnetään komentoa rsync ja sen tarkenninta --link-dest, jolloin
levytilaa kuluu vain sen verran kuin uusia tiedostoja on tullut sekä
hieman yleisrasitetta linkkien luomisesta. Näin päivän varmuuskopion
saa otettua nopeasti vaikka otettaisiin kopiota etäkoneesta
hitaahkolla yhteydellä eikä levylle tarvitse tallentaa useaa kopiota
täsmälleen samasta tiedostosta. 

Komentotiedoston voi käynnistää cronista, se osaa itse siivota
jälkensä ja poistaa edellisen kuukauden tiedostot. Varmuuskopioitaessa
etäkonetta pitää tällöin järjestää kirjautuminen SSH:lla ilman
salasanan kysymistä. Tämä onnistuu helposti ja turvallisesti
käyttämällä tunnistamiseen SSH-avainta, ohje löytyy esimerkiksi
lähteistä [1] ja [2].

Vaatimukset
===========

Komentotiedosto käyttää komentoa rsync, semmoinen on siis koneesta
valmiiksi asennettuna löydyttävä. Samoin tarvitaan ssh-asiakasohjelma
siinä koneessa missä tätä komentotiedostoa käytetään sekä ssh-palvelin
etäkoneessa josta varmuuskopio otetaan.

Hakemisto johon varmuuskopiot tallennetaan pitää olla semmoisella
tiedostojärjestelmällä jossa on hard linkit. Unix- ja
Linux-tiedostojärjestelmissä tämä ominaisuus on, kaikissa Windowsissa
käytettävissä tiedostojärjestelmissä ei ole. 

Käyttö
======

Komentotiedostolla on sisäänrakennettu ohje, sen saa näkyviin
tarkentimella --help. Tarvittavat tarkentimat ovat
 -f --fromhost: käyttäjätunnus ja konenimi. Tällä käyttäjätunnuksella
                kirjaudutaan sisään koneeseen. Pitää päättyä
		kaksoispiste-merkkiin. Esimerkki:
		-f root@jokukone.esimerkki.net:
 -t --tdir:     kohdehakemisto, se jonka alihakemistoiksi
                varmuuskopiot tulevat
 -r --rsynctodir: Jos on jo tehtynä rsync-kopio muuten kuin
                tällä komentotiedostolla, sen voi antaa tässä
		niin noudetaan vain muuttuneet osat. Tämän hakemiston
		on oltava samassa tiedostojärjestelmässä kuin tdir,
		muuten linkit eivät onnistu.
 -v --verbose:  Ylimääräistä tulostusta komentotiedoston toiminnan 
                seuraamiseen. Helpottaa vianetsintää ja auttaa
		näkemään komentotiedoston tosiaan tehneen jotain.
 -h --help:     Tulostaa ohjeen.

Samalla komennolla voi ottaa kopion useasta
alihakemistopuusta. Alihakemistot käsitellään yksitellen siinä
järjestyksessä kuin ne on komentoriville kirjoitettu.

Esimerkki näyttää miten crontab kirjoitetaan käynnistämään
etävarmistus. Tuo @daily -rivi pitää kirjoittaa yhtenä rivinä, se
näkyy taitettuna tässä jottei rivin loppu katoaisi oikeaan
marginaaliin. 

wally:~# crontab -l
MAILTO=oma.sähköpostiosoite@dnainternet.net
SHELL=/bin/bash
LC_TIME=fi_FI.UTF-8
# m h dom mon dow
@daily	      /root/bin/etavarmista.sh -v -f root@fcjazz-j.dyndns.org:
-t /opt/Varmuuskopiot/toppari /etc /root /home /var/www

Kun komentotiedosto käynnistetään ensimmäistä kertaa tdir hakemistoon,
(siis kun hakemisto tdir on tyhjä tai siellä ei ainakaan ole
LATEST-nimistä hakemistoa) eikä käytetä tarkenninta --rsynctodir,
tulee seuraava ilmoitus:
--link-dest arg does not exist: /root/Varmuuskopiot/toppari/LATEST

Ilmoitus on kuvatussa tilanteessa normaali, eikä sitä enää tule kun
seuraavana päivänä käynnistetään komentotiedosto seuraavan kerran. 

Komentotiedosto ei toimi järkevästi jos se käynnistetään kaksi kertaa
saman vuorokauden aikana. Silloin se tyhjentää aiemmin tehdyn
hakemiston ja aloittaa uudestaan nollasta.

Komennon rsync tarkennin --link-dest siis ei tallenna uudestaan
täsmälleen samanlaista tiedostoa, tekeepä vain hard
linkin. Näitä hard linkkejä on hankala huomata, ei oikein taida olla
muuta keinoa kuin ajaa komento ls -li päiväkohtaisissa hakemistoissa
ja verrata onko sama inode-numero muillakin tiedostoilla. Mutta
levytilaa kuluu vähemmän, mutta tämänkin toteaminen pitää tehdä
oikealla tavalla. Jos komennolla du -sh katsoo hakemistojen kokoa
yksitellen, näyttävät ne kaikki suunnilleen saman kokoisilta:

bubba:~/Scripts/trunk# du -sh  /home/Varmuuskopiot/toppari/maanantai/ 
9.5G	/home/Varmuuskopiot/toppari/maanantai/

bubba:~/Scripts/trunk# du -sh  /home/Varmuuskopiot/toppari/tiistai/
9.5G	/home/Varmuuskopiot/toppari/tiistai/

Tämä siksi, että ne hard linkit ovat tavallisia tiedostoja eikä du
vain yhtä päiväkohtaista hakemistopuuta katsomalla huomaa samaa inodea
olevan muuallakin. Levytilan säästymisen huomaa kun samalla
du-komennolla katsoo useampia hakemistopuita:

bubba:~/Scripts/trunk# du -sh  /home/Varmuuskopiot/toppari/*
0	/home/Varmuuskopiot/toppari/LATEST
9.5G	/home/Varmuuskopiot/toppari/maanantai
35M	/home/Varmuuskopiot/toppari/tiistai

Lähteet
=======

1. http://www.debian-administration.org/articles/152
Debian Administration Password-less logins with OpenSSH

2. http://www.hackinglinuxexposed.com/articles/20021211.html
Hacking Linux Exposed
Secure Passwordless Logins with SSH Part 1 - 4 
By Brian Hatch.
